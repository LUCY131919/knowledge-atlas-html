---
name: knowledge-atlas-html
description: 把知识库编译成或修改「知识宇宙」单文件 HTML 可视化网页，含看板 / 世界地图 / 思维导图 / 知识操作系统 / AI 智慧 五个视图。当用户要把思维导图（.emmx）、PDF、笔记或 JSON/Markdown 知识库整理成可点进去、可逐层下钻、可跨学科跳转的网页时使用；也用于在既有知识宇宙网页上补数据、扩建大陆、改视图、清乱码与交付前体检。不适用于制作 .pptx / Google Slides 演示稿，或与知识可视化无关的普通网页。
metadata:
  short-description: 知识库编译成单文件知识宇宙可视化网页
---

# 知识宇宙 HTML

把任意知识库编译成一个**零依赖的单文件网页**：双击即开、可投屏、可邮件发送、可离线。

产物是 `aad-universe.html` 这一类的文件：顶部五个视图切换（看板 / 世界地图 / 思维导图 / 知识操作系统 / AI 智慧），
数据全部内联在 `const KB` 里，不请求任何后端、不需要联网。

先确认要交付的是**这个**（单文件网页），而不是 PPT 或普通网站脚手架。

## 数据模型

层级固定四层，全部落在 `const KB` 里：

```
大陆 land → 学脉 branch → 专题 topic → 要点 point
```

字段表、`archive` 原文归档指令、17 个大陆的配色表，完整说明见 `references/data-schema.md`。**写 `kb.json` 前先读它。**

## 构建流程

```bash
# 1) 来源是 .emmx（亿图脑图 / EdrawMind）时，先提取节点原文，一条一行
python scripts/extract_emmx.py "AAD多元知识思维模型框架体系1.0.emmx" -o rec_1.txt

# 2) 按 references/data-schema.md 组装 kb.json
#    原始框架用 archive 指令指向 rec_1.txt，不要手工拆分、不要改写

# 3) 灌进模板，产出单文件网页
python scripts/build_atlas.py --kb kb.json --out 知识宇宙.html --built 2026.10.15

# 4) 交付前体检，必须「错误 0」
python scripts/check_atlas.py --html 知识宇宙.html
```

`build_atlas.py` 会把模板里的 `const KB = ...;` 整行替换成你的数据，并重算所有计数
（每层条数、`meta.nodes` / `meta.points` / `meta.lands` / `meta.built`），所以 **不要手写任何计数**。

`check_atlas.py` 的警告多半指向来源数据本身的问题（重复要点、半句碎片、部首异形字、超长要点），要逐条判断，
不要为了消警告去改用户的原文。

模板默认用 `assets/atlas-template.html`，可以用 `--template` 换成别的基础模板。

## 五个视图

| 视图 | 作用 |
|---|---|
| 看板 | 首页总览：主标题、KPI（节点 / 大陆 / 要点 / 层级）、大陆分布条形、层级刻度 |
| 世界地图 | 中央知识星球 + 各大陆沿轨道公转，点行星下钻到大陆 |
| 思维导图 | 中心椭圆 + 学科椭圆 + 指向性弧线，逐层下钻（大陆→学脉→专题→细分） |
| 知识操作系统 | 左学科树 / 中画布 / 右详情抽屉，日常查资料的主工作台 |
| AI 智慧 | 本地检索问答、动漫分镜草稿、可选接入外部大模型 |

URL hash 可直接深链：`#board` `#atlas` `#mind` `#os` `#ai`；
思维导图还支持 `#mind--land--<landId>`、`#mind--branch--<landId>--<学脉名>`、
`#mind--topic--<landId>--<学脉名>--<专题名>`。改数据时保持这些入口可用。

## 设计规格

这套可视化的骨架来自用户的原始设计（完整原文见 `references/design-history.md`）。改动前先理解，不要推翻：

- **「总—分—总」是主结构**：总（统一世界观）→ 分（学科体系 / 分析维度 / 跨学科网络 / 方法实践）→ 总（综合认知与持续进化）。
  跨学科关联负责打破树状限制：同一个知识点可以既留在原位，又从别的学科进入。
- **「高维 / 中维 / 低维」是分析层，不是学科分类**：高维＝整体与原则、中维＝结构与机制、低维＝证据与行动；
  它不指数空间维数，高维也不比低维更正确。界面措辞用户已定为 **道 / 法 / 术 / 器**（模板里的 `AXES`），
  不要退回「高维 / 中维 / 低维」。
- **三种可视化各有分工，不合并**：世界地图做品牌与探索体验，思维导图保证结构严谨，知识操作系统承担日常操作。
- **每个知识点都要能「点进去、展开、跨出去」**：单击看详情、双击进下一级、点关系线看关联理由、全局搜索、路径导航；
  同一节点在所有视图里保持一致。
- 视觉令牌是「马卡龙 × 编辑排版」：亮纸底、国际风、衬线大标题。模板 `:root` 里已定义齐全，优先复用变量，
  不要引入新色系、不要改回深色底。

## 硬性约束

用户对「字对不上」极其敏感，这几条是底线：

- **原始框架只放原文**：从 `.emmx` 等来源提取的记录，一个字都不要改——不摘要、不解读、不 AI 补写。用 `archive` 指令整体归档，不拆句。
- **对不上就删掉或留空，绝不臆造**。宁可空着，也不要编一句看起来像模像样的话。
- 不要出现 `原始条目`、`未分学脉` 这类占位文字，用户已明确要求清零。
- 数据里不能有 U+FFFD（解码失败留下的替换字符），不要部首异形字（⼩⽶⻛ 这类，`check_atlas.py` 会报）。
- 数据里出现 `</` 会提前结束 `<script>`，构建脚本会直接拦下。

## 改一个既有的成品网页

成品是单文件、数据内联，**不要直接手改 HTML 里的数据**。正确做法：

1. 从成品里取出 `const KB = ...;` 那一行（它是一行，形状见 `check_atlas.py` 的 `KB_LINE`），存成 `kb.json`
2. 改 `kb.json`（补大陆、改要点、清乱码）
3. 用 `build_atlas.py` 重新生成，再跑 `check_atlas.py`

模板自带三块 AAD 专属数据，换项目或改数据时要一并核对，否则会串味：

- `const NOTES` —— 要点抽屉「完整原名」短标签映射
- `const GLOSSARY` —— 抽屉「详细解说」的原理补充词库
- `const STORY_TPL` —— AI 动漫解说页的分镜模板

## 自检

除了跑 `check_atlas.py`，还要**真的看一眼**。用 Edge 旧版 headless 截图：

```powershell
& msedge --headless --disable-gpu --no-sandbox --in-process-gpu --user-data-dir="$env:TEMP\edge-shot" `
  --window-size=1600,1100 --screenshot="$pwd\shot.png" "file:///$pwd/out.html" 2>&1 | Out-Null
```

两个坑：新版 `--headless=new` 在这台机器上会崩（`GPU process isn't usable`），必须用旧版 `--headless`；
PowerShell 里必须把 stderr 重定向掉，否则截图文件写不出来。headless 只能验证首屏，交互要在真浏览器里点一遍。

## 参考

- `references/data-schema.md` —— KB JSON 字段、`archive` 指令、大陆配色
- `references/design-history.md` —— 原始设计规格全文、逐版迭代史、踩过的坑
- `references/aad-project-prompts.txt` —— AAD 项目 24 条原始提示词（含语音转写原文）
- `assets/atlas-template.html` —— 默认模板
- `assets/previews/` —— 五个视图的成品截图，用来说明目标观感
