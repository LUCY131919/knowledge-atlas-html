# 知识库数据格式（KB JSON）

模板里只有一行数据：

```js
const KB = {"meta":{...},"lands":[...]};
```

`scripts/build_atlas.py` 会把这一行整体替换成你的数据并重算计数。所以给脚本的 `kb.json`
只需包含 `meta` 和 `lands`。

## 结构

```json
{
  "meta": {
    "title": "AAD 多元知识宇宙",
    "sub": "MULTI-DISCIPLINARY KNOWLEDGE ATLAS",
    "levels": 5,
    "built": "2026.10.15"
  },
  "lands": [
    {
      "id": "models",
      "name": "各学科模型",
      "en": "DISCIPLINARY MODELS",
      "c": "#A8E6CF",
      "ci": "#1E6B4F",
      "blurb": "心理学 · 哲学 · 经济学 · 数学 · 物理 · 工程学",
      "branches": [
        {
          "name": "心理学",
          "topics": [
            {"name": "人格与识人", "points": ["九型人格", "大五人格 OCEAN"]}
          ]
        }
      ]
    }
  ]
}
```

层级固定是四层：**大陆 land → 学脉 branch → 专题 topic → 要点 point**。

| 字段 | 必填 | 说明 |
|---|---|---|
| `meta.title` / `meta.sub` | 否 | 网页标题与副标题 |
| `meta.levels` | 否 | 默认 5，看板展示用 |
| `meta.built` | 否 | 由脚本写入当天日期 |
| `meta.nodes` / `meta.points` / `meta.lands` | — | **不要手写**，脚本会重算 |
| `land.id` | 是 | 英文小写短 id，全站唯一且**改动后旧链接会失效** |
| `land.name` / `land.en` | 是 | 中文名 / 英文名 |
| `land.c` / `land.ci` | 是 | 大陆配色：`c` 浅色底、`ci` 同色系深色文字 |
| `land.blurb` | 否 | 一句话介绍，用 ` · ` 分隔关键词 |
| `branch.name` | 是 | 同一大陆内唯一 |
| `branch.en` | 否 | 英文名 |
| `branch.n` / `land.n` | — | 不要手写，脚本会重算 |
| `topic.name` | 是 | 同一学脉内唯一；建议用真实内容当标题 |
| `topic.points` | 是 | 字符串数组，一条 = 一个要点，**原样保留来源文字** |

## 记录归档：archive 指令

「一行一条记录」的文件（例如 `.emmx` 提取出来的原文）不用手工拆专题，写一句声明即可：

```json
{"name": "AAD 1.0 原始框架",
 "archive": {"file": "rec_1.txt", "prefix": "1.0", "chunk": 50}}
```

- `file`：记录文件路径，相对 `kb.json` 所在目录
- `chunk`：每多少条一个专题，默认 50
- `prefix`：要点编号前缀，产出 `1.0-001`、`1.0-002`…
- 专题名自动取该组第一条的前 16 字，形如 `001–050 · 学习方法`

适合做「原文归档」学脉：不切句、不改字、顺序与来源一致。用户明确要求过**原始框架只放原文、不要任何加工**，
所以归档学脉里不要混入摘要、解读或 AI 补写的内容。

## 配色

17 个大陆默认用这套（`c` / `ci`）：

| id | name | en | c | ci |
|---|---|---|---|---|
| `models` | 各学科模型 | DISCIPLINARY MODELS | #A8E6CF | #1E6B4F |
| `mental` | 思维模型 | MENTAL MODELS | #FFD3B6 | #8B4D2E |
| `wisdom` | 普世智慧 | UNIVERSAL WISDOM | #A0C4FF | #1E4A8B |
| `learning` | 学习方法 | LEARNING METHODS | #FDFFB6 | #6B6B1E |
| `value` | 价值体系 | VALUE SYSTEM | #DCD3FF | #4E3A8A |
| `wealth` | 财富观 | VIEW OF WEALTH | #FFADAD | #8B2E3A |
| `tarot` | 塔罗 | TAROT | #E2D5C5 | #5E4432 |
| `yijing` | 易经 | I CHING | #9BF6FF | #1E6B73 |
| `neijing` | 黄帝内经 | HUANGDI NEIJING | #CAFFBF | #2E6B1E |
| `newwealth` | 新财商思维 | NEW FINANCIAL IQ | #FFD6A5 | #7A4D1E |
| `speech` | 沟通演讲 | SPEAKING | #CDB4DB | #5E3A6E |
| `sales` | 商业销售思维 | SALES THINKING | #FFC6A5 | #7A3A1E |
| `readpeople` | 识人术 | READING PEOPLE | #B5EAD7 | #1E5E4A |
| `spirit` | 高维智慧 | Higher Wisdom | #E8D7C4 | #8C7355 |
| `invest` | 投资哲学 | Investment Philosophy | #C8E0D0 | #3A6B52 |
| `biz` | 商业与股权 | Business & Equity | #D6D0E8 | #5E5480 |
| `insurance` | 保险与保障 | Insurance | #C8DCE8 | #3A6B8C |

新增大陆时自己挑一对同色系的浅/深色即可，浅色别太艳（要能压住黑字），深色要能压在浅色上。

## 网页外壳里另外两块可选数据

这两个是模板自带的增强数据，放在 `const KB` 之后的独立常量里，改数据时按需维护：

- `const NOTES = { "短名": {"full": "完整原文", "v": "1.0"} }`
  要点抽屉里的「完整原名」小标签用它：点到短标签时展示 `full`。
  `NOTES` 里**不能有乱码或臆造内容**，对不上就不要放。
- `const GLOSSARY = { "概念": "解释文字" }`
  抽屉里对某个要点做原理补充时用，优先级高于自动生成的兜底解释。
