#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把知识库 JSON 灌进「知识宇宙」HTML 模板，产出一个单文件网页。

模板里的数据结构是一行：  const KB = {"meta":{...},"lands":[...]};
本脚本把这一行整体替换成你的数据，然后重算所有计数（分支条数、大陆条数、
meta.nodes / meta.points / meta.lands / meta.built）。计数一律以实际数据为准，
不要手写。

数据格式见 ../references/data-schema.md。

专题里可以用 archive 指令，把「一行一条」的原始记录文件自动展开成专题：

    {"name": "AAD 1.0 原始框架",
     "archive": {"file": "rec_1.txt", "prefix": "1.0", "chunk": 50}}

规则：每 chunk 条一个专题，专题名形如 `001–050 · <第一条的前 16 字>`，
要点前缀形如 `1.0-001 `。

用法:
    python build_atlas.py --kb kb.json --out out.html
    python build_atlas.py --kb kb.json --out out.html --template 别的模板.html
    python build_atlas.py --kb kb.json --out out.html --title "我的知识宇宙"
"""
import argparse, datetime, io, json, os, re, sys

SCRIPT_LINE = re.compile(r"^const KB = .*?;\s*$", re.M)
CONT = "的地得而则就即这那其以与和但否并或把被让使从对于之等也才都会能是在有为很更最还又再只且，、；。！？—-·0123456789"


def short(text, n=16):
    text = re.sub(r"\s+", " ", text).strip()
    return text if len(text) <= n else text[:n] + "…"


def pick_title(points, span=10):
    def ok(x, lo, hi):
        x = re.sub(r"\s+", " ", x).strip()
        return lo <= len(x) <= hi and x[0] not in CONT and not x.endswith(("，", "、", "。"))
    for p in points[:span]:
        if ok(p, 4, 16):
            return short(p)
    for p in points:
        if ok(p, 2, 20):
            return short(p)
    return short(points[0])


def expand_archive(branch, base_dir):
    spec = branch.pop("archive")
    path = spec["file"]
    if not os.path.isabs(path):
        path = os.path.join(base_dir, path)
    with io.open(path, encoding="utf-8") as fh:
        # 原样保留记录文本（只去掉行尾换行），不要改动原始内容
        records = [line.rstrip("\r\n") for line in fh if line.strip()]

    chunk = int(spec.get("chunk", 50))
    prefix = spec.get("prefix", "")
    topics = []
    for i in range(0, len(records), chunk):
        part = records[i:i + chunk]
        topics.append({
            "name": "%03d–%03d · %s" % (i + 1, i + len(part), pick_title(part)),
            "points": ["%s-%03d %s" % (prefix, i + 1 + k, p) for k, p in enumerate(part)],
        })
    branch["topics"] = topics
    return branch


def load_template(path):
    with io.open(path, encoding="utf-8") as fh:
        html = fh.read()
    m = SCRIPT_LINE.search(html)
    if not m:
        raise SystemExit("模板里找不到 `const KB = ...;` 那一行：%s" % path)
    return html, m


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    default_tpl = os.path.join(here, os.pardir, "assets", "atlas-template.html")

    ap = argparse.ArgumentParser(description="知识库 JSON + 模板 -> 单文件 HTML")
    ap.add_argument("--kb", required=True, help="知识库 JSON（meta + lands）")
    ap.add_argument("--out", required=True, help="输出的 .html 路径")
    ap.add_argument("--template", default=default_tpl, help="模板 HTML，默认用 skill 自带的")
    ap.add_argument("--title", help="覆盖 meta.title")
    ap.add_argument("--sub", help="覆盖 meta.sub")
    ap.add_argument("--built", help="覆盖 meta.built，默认今天")
    ap.add_argument("--indent", type=int, default=None,
                    help="JSON 缩进；默认紧凑单行（文件更小）")
    a = ap.parse_args()

    kb_path = os.path.abspath(a.kb)
    with io.open(kb_path, encoding="utf-8") as fh:
        kb = json.load(fh)

    if "lands" not in kb or not isinstance(kb["lands"], list):
        raise SystemExit("知识库 JSON 顶层要有 lands 数组：%s" % a.kb)
    kb.setdefault("meta", {})

    base_dir = os.path.dirname(kb_path)
    for land in kb["lands"]:
        land.setdefault("branches", [])
        for branch in land["branches"]:
            if "archive" in branch:
                expand_archive(branch, base_dir)
            branch.setdefault("topics", [])
        land["branches"] = [b for b in land["branches"] if b["topics"]]

    kb["meta"]["lands"] = len(kb["lands"])
    if a.title:
        kb["meta"]["title"] = a.title
    if a.sub:
        kb["meta"]["sub"] = a.sub
    kb["meta"]["built"] = a.built or datetime.date.today().strftime("%Y.%m.%d")
    kb["meta"].setdefault("title", "知识宇宙")
    kb["meta"].setdefault("sub", "MULTI-DISCIPLINARY KNOWLEDGE ATLAS")
    kb["meta"].setdefault("levels", 5)

    nodes = points = 0
    for land in kb["lands"]:
        land["n"] = 0
        for branch in land["branches"]:
            branch["n"] = sum(len(t["points"]) for t in branch["topics"])
            land["n"] += branch["n"]
            nodes += len(branch["topics"])
            points += branch["n"]
    kb["meta"]["nodes"] = nodes
    kb["meta"]["points"] = points

    payload = json.dumps(kb, ensure_ascii=False,
                         indent=a.indent, separators=None if a.indent else (",", ":"))
    if "</" in payload:
        raise SystemExit("数据里出现了 `</`，会提前结束 <script>，请先清掉。")

    html, m = load_template(a.template)
    html = html[:m.start()] + "const KB = " + payload + ";" + html[m.end():]

    with io.open(a.out, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(html)

    size = os.path.getsize(a.out) / 1024.0
    print("已写出 %s（%.0f KB）" % (a.out, size))
    print("大陆 %d / 学脉 %d / 专题 %d / 要点 %d"
          % (len(kb["lands"]),
             sum(len(l["branches"]) for l in kb["lands"]), nodes, points))


if __name__ == "__main__":
    main()
