#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""从 EdrawMind / 亿图脑图 的 .emmx 文件里提取节点文本。

.emmx 就是一个 zip，脑图节点文本存在 mmpage/page.bin 里。
page.bin 是二进制记录流，每条文本字段的格式是：

    01 02 <字段号:1字节含高位> 01 04 <UTF-8 文本> 00

同一位置会出现连续两个字段标记（前一个字段为空），所以要跳过「后面紧跟另一个
标记」的那种。按这个规则提取，AAD 1.0 得到 981 条、AAD 2.0 得到 450 条，与人工
核对过的结果逐字一致。

用法:
    python extract_emmx.py 脑图.emmx                      # 打印到屏幕
    python extract_emmx.py 脑图.emmx -o records.txt       # 一条一行写到文件
    python extract_emmx.py 脑图.emmx --json -o records.json
"""
import argparse, json, re, sys, zipfile

MARKER = re.compile(rb"\x01\x02[\x80-\xff]?\x01\x04")
MEMBER = "mmpage/page.bin"


def extract(path):
    with zipfile.ZipFile(path) as zf:
        names = zf.namelist()
        if MEMBER not in names:
            raise SystemExit("%s 里没有 %s，可能不是 .emmx 脑图文件。实际内容：%s"
                             % (path, MEMBER, ", ".join(names[:12])))
        data = zf.read(MEMBER)

    out = []
    for m in MARKER.finditer(data):
        i = m.end()
        if data[i:i + 2] == b"\x01\x02":     # 紧跟另一个字段标记 = 本字段为空
            continue
        j = data.find(b"\x00", i)
        if j < 0:
            continue
        try:
            text = data[i:j].decode("utf-8")
        except UnicodeDecodeError:           # 二进制噪声，不是文本字段
            continue
        if text.strip():
            out.append(text)
    return out


def main():
    ap = argparse.ArgumentParser(description="提取 .emmx 脑图里的节点文本")
    ap.add_argument("emmx", help=".emmx 文件路径")
    ap.add_argument("-o", "--out", help="输出文件；省略则打印到屏幕")
    ap.add_argument("--json", action="store_true", help="以 JSON 数组输出，默认一行一条")
    a = ap.parse_args()

    records = extract(a.emmx)
    print("提取到 %d 条节点文本" % len(records), file=sys.stderr)

    if a.json:
        payload = json.dumps(records, ensure_ascii=False, indent=1)
    else:
        payload = "\n".join(records)
    if a.out:
        with open(a.out, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(payload + "\n")
        print("已写出 %s" % a.out, file=sys.stderr)
    else:
        print(payload)


if __name__ == "__main__":
    main()
