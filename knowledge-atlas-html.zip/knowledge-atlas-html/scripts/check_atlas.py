#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""交付前体检：校验知识宇宙 HTML 的语法与数据质量。

用法:
    python check_atlas.py --html out.html
    python check_atlas.py --html out.html --strict      # 有警告也返回非 0

检查项
  错误（一定返回非 0）
    - 内嵌 JS 语法（有 node 就跑 node --check）
    - 同一个大陆里学脉重名 / 同一个学脉里专题重名
    - 空专题、空学脉、空要点
    - 要点里出现 U+FFFD（替换字符 = 解码失败留下的伤）
    - KB JSON 里出现 `</`（会提前结束 <script>）
    - meta 计数与实际数据对不上
  警告
    - 同一学脉内重复的要点
    - 明显是「半句碎片」的要点（是同学脉另一条要点的子串）
    - 部首异体字（U+2E80–U+2FDF、U+F900–U+FAFF，例：⼩⽶⻛）
    - 超长要点（> 200 字）
"""
import argparse, json, os, re, subprocess, sys, tempfile

SCRIPT_BLOCK = re.compile(r"<script[^>]*>(.*?)</script>", re.S)
KB_LINE = re.compile(r"^const KB = (.*);\s*$", re.M)
NORM = re.compile(r"[^0-9A-Za-z\u4e00-\u9fff]")


def norm(text):
    return NORM.sub("", text or "")


def odd_chars(text):
    return {c for c in text if 0x2E80 <= ord(c) <= 0x2FDF or 0xF900 <= ord(c) <= 0xFFDC
            and (0x2E80 <= ord(c) <= 0x2FDF or 0xF900 <= ord(c) <= 0xFAFF)}


def main():
    ap = argparse.ArgumentParser(description="校验知识宇宙 HTML")
    ap.add_argument("--html", required=True)
    ap.add_argument("--strict", action="store_true", help="警告也视为失败")
    a = ap.parse_args()

    errors, warns = [], []
    html = open(a.html, encoding="utf-8").read()

    # 1) 内嵌 JS 语法
    blocks = SCRIPT_BLOCK.findall(html)
    if not blocks:
        errors.append("找不到 <script> 块")
    if blocks and blocks[0].count("const KB = ") != 1:
        errors.append("脚本里应该有且只有一处 `const KB = `")

    m = KB_LINE.search(blocks[0]) if blocks else None
    if not m:
        errors.append("脚本里找不到 `const KB = ...;` 那一行")
    if errors:
        for e in errors:
            print("错误: " + e)
        return 1

    if "</" in m.group(1):
        errors.append("KB 数据里含 `</`，会提前结束 <script>")

    if blocks and os.system("node --version >NUL 2>NUL") == 0:
        with tempfile.TemporaryDirectory() as tmp:
            for idx, code in enumerate(blocks):
                fp = os.path.join(tmp, "block%d.js" % idx)
                open(fp, "w", encoding="utf-8").write(code)
                r = subprocess.run(["node", "--check", fp], capture_output=True, text=True)
                if r.returncode:
                    errors.append("内嵌 JS 语法错误（node --check）：\n" + (r.stderr or "").strip()[:800])

    kb = json.loads(m.group(1))
    lands = kb.get("lands", [])

    nodes = points = 0
    for land in lands:
        names = {}
        for b in land.get("branches", []):
            if not b.get("topics"):
                errors.append("空学脉：%s / %s" % (land.get("name"), b.get("name")))
                continue
            names[b["name"]] = names.get(b["name"], 0) + 1
            seen = {}
            for t in b["topics"]:
                pts = t.get("points") or []
                if not pts:
                    errors.append("空专题：%s / %s / %s" % (land.get("name"), b["name"], t.get("name")))
                    continue
                nodes += 1
                seen[t["name"]] = seen.get(t["name"], 0) + 1
                normed = [norm(p) for p in pts]
                for p, np_ in zip(pts, normed):
                    points += 1
                    if not isinstance(p, str) or not p.strip():
                        errors.append("空要点：%s / %s / %s" % (land.get("name"), b["name"], t["name"]))
                        continue
                    if "\ufffd" in p:
                        errors.append("要点含替换字符 U+FFFD：%s / %s / %s" % (land.get("name"), b["name"], p[:40]))
                    if odd_chars(p):
                        warns.append("部首异体字：%s / %s / %s" % (land.get("name"), b["name"], p[:40]))
                    if len(p) > 200:
                        warns.append("超长要点(%d 字)：%s / %s" % (len(p), b["name"], p[:30]))
                dup = len(normed) - len(set(normed))
                if dup:
                    warns.append("重复要点 %d 条：%s / %s / %s" % (dup, land.get("name"), b["name"], t["name"]))
                for i, p in enumerate(normed):
                    if len(p) < 4:
                        continue
                    for j, q in enumerate(normed):
                        if i != j and p in q and len(p) < len(q):
                            warns.append("疑似碎片：%s / %s / 「%s」 ⊂ 「%s…」"
                                         % (land.get("name"), b["name"], pts[i][:20], pts[j][:20]))
                            break
            for name, c in seen.items():
                if c > 1:
                    errors.append("专题重名 %d 次：%s / %s / %s" % (c, land.get("name"), b["name"], name))
        for name, c in names.items():
            if c > 1:
                errors.append("学脉重名 %d 次：%s / %s" % (c, land.get("name"), name))

    meta = kb.get("meta", {})
    if meta.get("nodes") != nodes:
        errors.append("meta.nodes=%s，实际 %d" % (meta.get("nodes"), nodes))
    if meta.get("points") != points:
        errors.append("meta.points=%s，实际 %d" % (meta.get("points"), points))
    if meta.get("lands") != len(lands):
        errors.append("meta.lands=%s，实际 %d" % (meta.get("lands"), len(lands)))

    for e in errors:
        print("错误: " + e)
    shown = warns[:40]
    for w in shown:
        print("警告: " + w)
    if len(warns) > len(shown):
        print("警告: ...另有 %d 条同类警告" % (len(warns) - len(shown)))

    print("\n大陆 %d / 学脉 %d / 专题 %d / 要点 %d —— 错误 %d，警告 %d"
          % (len(lands), sum(len(l.get("branches", [])) for l in lands), nodes, points,
             len(errors), len(warns)))
    if errors or (a.strict and warns):
        return 1
    print("体检通过。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
